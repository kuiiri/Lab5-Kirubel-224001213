const form = document.getElementById('regForm');
const cards = document.getElementById('cards');
const summaryBody = document.querySelector('#summary tbody');


form.addEventListener('submit', (e) => {
e.preventDefault();


const first = document.getElementById('first').value.trim();
const last = document.getElementById('last').value.trim();
const prog = document.getElementById('prog').value.trim();
const year = document.getElementById('year').value;
const photoInput = document.getElementById('photo');


if (!first || !last || !prog || !year) {
alert('Please fill in all required fields.');
return;
}


let photoURL = 'https://via.placeholder.com/100';
if (photoInput.files && photoInput.files[0]) {
photoURL = URL.createObjectURL(photoInput.files[0]);
}


const id = Date.now();


// Card
const card = document.createElement('div');
card.className = 'card-person';
card.dataset.id = id;
card.innerHTML = `
<img src="${photoURL}" alt="${first} ${last}">
<h3>${first} ${last}</h3>
<div>
<span class="badge prog">${prog}</span>
<span class="badge year">Year ${year}</span>
</div>
`;
cards.appendChild(card);


// Table row
const row = document.createElement('tr');
row.dataset.id = id;
row.innerHTML = `
<td>${first} ${last}</td>
<td>${prog}</td>
<td>${year}</td>
`;
summaryBody.appendChild(row);


form.reset();
});